/*
 * Copyright (C) 2014 Pedro Vicente Gómez Sánchez.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.github.pedrovgs.mincostmaxflow;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

public class MinCostMaxFlowManualTest {

  @Test(expected = IllegalArgumentException.class)
  public void shouldRejectToNodeOutOfBoundsInAddEdge() {
    MinCostMaxFlow flow = new MinCostMaxFlow(3);
    flow.addEdge(1, 3, 1, 1);
  }

  @Test(expected = IllegalArgumentException.class)
  public void shouldRejectOutOfBoundsSourceWhenOptionsNull() {
    MinCostMaxFlow flow = new MinCostMaxFlow(2);
    flow.minCostMaxFlow(2, 1, null);
  }

  @Test
  public void shouldClampAugmentingFlowToRemainingLimit() {
    MinCostMaxFlow flow = new MinCostMaxFlow(2);
    flow.addEdge(0, 1, 5, 3);

    MinCostMaxFlow.FlowOptions options = MinCostMaxFlow.FlowOptions.defaults().withMaxFlow(1);
    Pair<Integer, Long> result = flow.minCostMaxFlow(0, 1, options);

    assertEquals(new Pair<Integer, Long>(1, 3L), result);
  }

  @Test
  public void shouldAllowNonNegativeCostsWhenDisallowFlagEnabled() {
    MinCostMaxFlow flow = new MinCostMaxFlow(3);
    flow.addEdge(0, 1, 2, 1);
    flow.addEdge(1, 2, 2, 1);

    MinCostMaxFlow.FlowOptions options = MinCostMaxFlow.FlowOptions.defaults()
        .withAllowNegativeCosts(false);

    Pair<Integer, Long> result = flow.minCostMaxFlow(0, 2, options);
    assertEquals(new Pair<Integer, Long>(2, 4L), result);
  }

  @Test
  public void shouldPassNegativeCycleCheckWhenGraphHasNoNegativeCycle() {
    MinCostMaxFlow flow = new MinCostMaxFlow(4);
    flow.addEdge(0, 1, 1, 1);
    flow.addEdge(1, 2, 1, 1);
    flow.addEdge(2, 3, 1, 1);

    MinCostMaxFlow.FlowOptions options = MinCostMaxFlow.FlowOptions.defaults()
        .withNegativeCycleCheck(true);

    Pair<Integer, Long> result = flow.minCostMaxFlow(0, 3, options);
    assertEquals(new Pair<Integer, Long>(1, 3L), result);
  }

  @Test
  public void shouldUseBellmanFordWithUnreachableNodes() {
    MinCostMaxFlow flow = new MinCostMaxFlow(4);
    flow.addEdge(0, 1, 1, 2);
    flow.addEdge(1, 2, 1, 2);
    // Node 3 stays unreachable from source.

    MinCostMaxFlow.FlowOptions options = MinCostMaxFlow.FlowOptions.defaults()
        .withBellmanFordInitPotentials(true)
        .withMaxFlow(1);

    Pair<Integer, Long> result = flow.minCostMaxFlow(0, 2, options);
    assertEquals(new Pair<Integer, Long>(1, 4L), result);
  }

  @Test
  public void shouldExercisePairHashCode() {
    Pair<Integer, Long> a = new Pair<Integer, Long>(1, 2L);
    Pair<Integer, Long> b = new Pair<Integer, Long>(1, 2L);
    Pair<Integer, Long> c = new Pair<Integer, Long>(2, 2L);

    assertEquals(a.hashCode(), b.hashCode());
    assertNotEquals(a.hashCode(), c.hashCode());
  }
  @Test
  public void shouldCoverZeroCapacityOriginalEdgesInInternalScans() {
    MinCostMaxFlow flow = new MinCostMaxFlow(2);
    flow.addEdge(0, 1, 0, -1);

    MinCostMaxFlow.FlowOptions options = MinCostMaxFlow.FlowOptions.defaults()
        .withNegativeCycleCheck(true)
        .withBellmanFordInitPotentials(true);

    Pair<Integer, Long> result = flow.minCostMaxFlow(0, 1, options);
    assertEquals(new Pair<Integer, Long>(0, 0L), result);
  }
}
