/*
 * Copyright (C) 2014 Pedro Vicente Gómez Sánchez.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.github.pedrovgs.suffixarrayextras;

import org.junit.Test;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;

public class SuffixArrayExtrasManualTest {

  @Test
  public void shouldReturnEmptyLongestRepeatedForSingleCharacter() {
    assertEquals("", SuffixArrayExtras.longestRepeatedSubstringNaive("a"));
  }

  @Test
  public void shouldReturnEmptyLongestRepeatedForEmptyInput() {
    assertEquals("", SuffixArrayExtras.longestRepeatedSubstringNaive(""));
  }

  @Test
  public void shouldComputeZeroLengthArraysForEmptyInputAlgorithms() {
    assertArrayEquals(new int[0], SuffixArrayExtras.zAlgorithm(""));
    assertArrayEquals(new int[0], SuffixArrayExtras.prefixFunction(""));
  }

  @Test(expected = IllegalArgumentException.class)
  public void shouldRejectNullForCountDistinctSubstrings() {
    SuffixArrayExtras.countDistinctSubstrings(null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void shouldRejectNullForBurrowsWheelerTransform() {
    SuffixArrayExtras.burrowsWheelerTransform(null);
  }

  @Test
  public void shouldCapDistinctSubstringsAtIntegerMaxValue() {
    StringBuilder sb = new StringBuilder(65536);
    for (int i = 0; i <= 65535; i++) {
      sb.append((char) i);
    }
    assertEquals(Integer.MAX_VALUE, SuffixArrayExtras.countDistinctSubstrings(sb.toString()));
  }

  @Test(expected = IllegalArgumentException.class)
  public void shouldRejectNonAsciiInInverseBurrowsWheeler() {
    SuffixArrayExtras.BwtResult result = new SuffixArrayExtras.BwtResult("\u0100", 0, '\u0001');
    SuffixArrayExtras.inverseBurrowsWheeler(result);
  }

  @Test(expected = IllegalStateException.class)
  public void shouldRejectInvalidSentinelInInverseBurrowsWheeler() {
    SuffixArrayExtras.BwtResult result = new SuffixArrayExtras.BwtResult("ab", 0, 'z');
    SuffixArrayExtras.inverseBurrowsWheeler(result);
  }

  @Test(expected = IllegalStateException.class)
  public void shouldFailWhenNoAsciiSentinelAvailable() {
    StringBuilder sb = new StringBuilder();
    for (int i = 1; i < 256; i++) {
      sb.append((char) i);
    }
    SuffixArrayExtras.burrowsWheelerTransform(sb.toString());
  }
}
